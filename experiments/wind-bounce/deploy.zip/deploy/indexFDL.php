<?php
// platform check for excluding mobile content
$iphone = strpos($_SERVER['HTTP_USER_AGENT'],'iPhone');
$ipod = strpos($_SERVER['HTTP_USER_AGENT'],'iPod');
$ipad = strpos($_SERVER['HTTP_USER_AGENT'],'iPad');
$android = strpos($_SERVER['HTTP_USER_AGENT'],'Android');
$isMobile = false;
if($iphone || $ipod || $ipad || $android) {
  $isMobile = true;
}

// handle google ajax spidering code if the query param is passed:
// convert our deeplinks to the php include file for that section
$isAjaxCrawler = false;
$fragment_request = $_REQUEST['_escaped_fragment_'];
$fragment_request = substr( $fragment_request, 1 );  // strip leading slash
$fragment_request = str_replace( "-" , "_" , $fragment_request ); // dashes become underscores
$fragment_request = str_replace( "/" , "_" , $fragment_request ); // for sub-sections
$include_file = './php/pages/' . $fragment_request . '.php';
if( isset( $fragment_request ) && file_exists( $include_file ) ) $isAjaxCrawler = true;
// OVERRIDE FOR NOW, BECAUSE IE IS A PIECE OF SHIT
$isAjaxCrawler = false;
?><!doctype html>
<!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <?php if( $isAjaxCrawler == false ) { ?>
  <meta name="fragment" content="!">
  <?php } ?>
  <title>Factory Labs</title>
  <meta name="description" content="Factory Design Labs is a global leader in advertising premium culture-driven lifestyle brands, providing world-class strategic design">
  <meta name="author" content="Factory Design Labs 2011">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1">
  <link rel="shortcut icon" href="./favicon.ico">
  <link rel="apple-touch-icon" href="./apple-touch-icon.png">
  <?php if( isset( $_REQUEST['dev'] ) ) { ?>
  <link rel="stylesheet" type="text/css" href="stylesheets/en/reset.css" />
  <link rel="stylesheet" type="text/css" href="stylesheets/en/application.css" />
  <?php } else { ?>
  <link rel="stylesheet" href="stylesheets/en/interface-min.css" type="text/css" media="all" title="interface" />    
  <?php } ?>
  <script src="javascripts/libs/modernizr-1.6.min.js"></script>
</head>
<body>
  <?php 
  // exclude mobile content for specified platforms
  if(!$isMobile) { 
  ?>
  <h1 id="fdl_h1">Factory Design Labs</h1>
  <div id="main_nav">
    <a id="orange_menu_btn" class="orange" href="#/orange">the power of orange</a>
    <a id="reel_menu_btn" class="main_nav" href="#/reel">reel</a>
    <a class="main_nav" href="#/work">work</a>
    <a class="main_nav" href="#/culture">culture</a>
    <a class="main_nav" href="http://careers.factorylabs.com/">careers</a>
    <a class="main_nav" href="#/contact">contact</a>
    <a class="main_nav" href="#/downloads">downloads</a>
    <a id="audio" href="#audio_toggle"></a>
    <a id="logo" href="#/home"><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/logo_fdl.png" width="109" height="19" alt="Factory Design Labs"></a>
  </div>
  <div id="drop_up_holder">
    <div id="videos_menu">
      <a href="#/snowflake"><span>snowflake</span><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/nav/video-snowflake.jpg" width="196" height="110" alt="snowflake" /></a>
      <a href="#/on-time"><span>on time</span><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/nav/video-on-time.jpg" width="196" height="110" alt="on time" /></a>
      <a href="#/headphones"><span>headphones</span><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/nav/video-headphones.jpg" width="196" height="110" alt="headphones" /></a>
      <a href="#/powder"><span>powder</span><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/nav/video-powder.jpg" width="196" height="110" alt="powder" /></a>
      <a href="#/leader"><span>leader</span><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/nav/video-leader.jpg" width="196" height="110" alt="leader" /></a>
    </div>
    <div id="reel_menu">
      <a href="#/reel"><span>reel</span><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/nav/video-reel.jpg" width="196" height="110" alt="reel" /></a>
    </div>
    <div id="work_menu">
      <!-- <div class="header">highlights</div> -->
      <a href="#/work/aspen">Aspen</a>
      <a href="#/work/audi">Audi</a>
      <a href="#/work/differences">Differences</a>
      <a href="#/work/eagle-creek">Eagle Creek</a>
      <a href="#/work/jim-russell">Jim Russell</a>
      <a href="#/work/killington">Killington</a>
      <a href="#/work/oakley">Oakley</a>
      <a href="#/work/revo">Revo</a>
      <a href="#/work/ruby-mountains">Ruby Mountains Heli</a>
      <a href="#/work/the-north-face">The North Face</a>
      <a href="#/work/vans">Vans</a>
      <div class="footer"><a href="#/reel">watch the reel</a></div>
    </div>
    <div id="careers_menu">
      <!-- <div class="header">careers</div> -->
      <a href="#/careers/copywriter">Copywriter</a>
      <div class="footer">&nbsp;</div>
    </div>
    <div id="html_content">
      <?php
      if( $isAjaxCrawler ) {
        include $include_file;
      } else {
        // by default, all content exists in the site
      ?>
      <!-- top-level html sections -->
      <div id="section_work" class="content_page">
        <?php include './php/pages/work.php' ?>
      </div>
      <div id="section_contact" class="content_page">
        <?php include './php/pages/contact.php' ?>
      </div>
      <div id="section_careers" class="content_page">
        <?php include './php/pages/careers.php' ?>
      </div>
      <div id="section_downloads" class="content_page">
        <?php include './php/pages/downloads.php' ?>
      </div>
      <!-- work sections -->
      <div id="section_aspen" class="content_page content_work">
      	<?php include './php/pages/work_aspen.php' ?>
      </div>
      <div id="section_audi" class="content_page content_work">
      	<?php include './php/pages/work_audi.php' ?>
      </div>
      <div id="section_differences" class="content_page content_work">
        <?php include './php/pages/work_differences.php' ?>
      </div>
      <div id="section_eagle-creek" class="content_page content_work">
        <?php include './php/pages/work_eagle_creek.php' ?>
      </div>
      <div id="section_jim-russell" class="content_page content_work">
        <?php include './php/pages/work_jim_russell.php' ?>
      </div>
      <div id="section_killington" class="content_page content_work">
        <?php include './php/pages/work_killington.php' ?>
      </div>
      <div id="section_oakley" class="content_page content_work">
        <?php include './php/pages/work_oakley.php' ?>
      </div>
      <div id="section_revo" class="content_page content_work">
        <?php include './php/pages/work_revo.php' ?>
      </div>
      <div id="section_ruby-mountains" class="content_page content_work">
        <?php include './php/pages/work_ruby_mountains.php' ?>
      </div>
      <div id="section_the-north-face" class="content_page content_work">
        <?php include './php/pages/work_the_north_face.php' ?>
      </div>
      <div id="section_vans" class="content_page content_work">
        <?php include './php/pages/work_vans.php' ?>
      </div>
      <!-- careers -->
      <div id="section_copywriter" class="content_page content_career">
        <?php include './php/pages/careers_copywriter.php' ?>
      </div>
      <?php
      // end google ajax crawling case
      }
      ?>
    </div>
  </div>
  <?php 
  // end mobile exclusion
  } 
  ?>
  <div id="container">
		<div id="flashcontent">
			<div class="mobile">
				<div class="logo">
					<a href="#/"><img src="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/images/mobile_logo.png" alt="F/" /></a>
				</div>
				<div class="section nav">
					<a href="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/media/videos/mobile/reel.m4v">reel</a><br />
					<a href="#/orange">orange</a><br />
					<a href="#/info">info</a>
				</div>
				<div class="section videos">
					<a href="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/media/videos/mobile/snowflake.m4v">snowflake</a><br />
					<a href="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/media/videos/mobile/on-time.m4v">on time</a><br />
					<a href="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/media/videos/mobile/headphones.m4v">headphones</a><br />
					<a href="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/media/videos/mobile/powder.m4v">powder</a><br />
					<a href="http://factorydl.http.internapcdn.net/factorydl_vitalstream_com/factorylabs/site09/media/videos/mobile/leader.m4v">leader</a><br />
				</div>
				<div class="section contact">
					<div class="content">
						<div class="content_left">
							<div class="one_third">
								<a class="maplink" href="http://maps.google.com/maps?f=q&hl=en&geocode=&q=158+Fillmore+St,+Denver,+CO+80206&sll=39.732706,-104.98742&sspn=0.00552,0.009398&ie=UTF8&z=16&iwloc=addr">map it</a>
								<a href="tel:1-888-663-5282">dial it</a>
							</div>
							<div class="one_third small_text">
								158 Fillmore St.<br />
								Denver, CO. 80206
							</div>
							<div class="one_third construction">
								<img src="media/images/construction-mobile.png" />
							</div>
							<div>888.663.5282</div>
						</div>
					</div>
					<div class="info">
						<a href="mailto:scott.mellin">Scott Mellin</a> / CEO<br />
						<a href="mailto:tracy.mcinnes">Tracy McInnes</a> / President<br />
						<a href="mailto:michael.bennett">Michael Bennett</a> / CFO<br />
						<a href="mailto:blake.ebel">Blake Ebel</a> / CCO<br />
						<a href="mailto:jonas.tempel">Jonas Tempel</a> / Chairman Special Projects<br />
						<a href="mailto:krista.molloy">Krista Molloy</a> / Human Resources
					</div>
				</div>
			</div>
		</div>
	</div>
  
        
  
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.5.0/jquery.min.js"></script>
  <script>!window.jQuery && document.write(unescape('%3Cscript src="javascripts/libs/jquery-1.5.min.js"%3E%3C/script%3E'))</script>
    
  <?php if( isset( $_REQUEST['dev'] ) ) { ?>
  <script type="text/javascript" src="javascripts/libs/swfobject.js"></script>
  <script type="text/javascript" src="javascripts/libs/swfaddress.js"></script>
  <script type="text/javascript" src="javascripts/libs/swffit.js"></script>
  <script type="text/javascript" src="javascripts/libs/swfengine.js"></script>
  <?php } else { ?>
  <script type="text/javascript" src="javascripts/min/lib-min.js"></script>
  <?php } ?>
  <?php if( isset( $_REQUEST['dev'] ) || true ) { 
    // FUCKING IE ISN'T PLAYING VIDEOS WITH MINIFIED APP. FIX THIS.
    ?>
  <script type="text/javascript" src="javascripts/fdl.js"></script>
  <?php } else { ?>
  <script type="text/javascript" src="javascripts/min/app-min.js"></script>
  <?php } ?>
  
  <!--[if lt IE 7 ]>
    <script src="javascripts/libs/dd_belatedpng.js"></script>
    <script> DD_belatedPNG.fix('img, .png_bg'); </script>
  <![endif]-->

  <script>
   var _gaq = [['_setAccount', 'UA-355166-2'], ['_trackPageview']];
   // _gaq.push(['_setAllowHash', true]);
   (function(d, t) {
    var g = d.createElement(t),
        s = d.getElementsByTagName(t)[0];
    g.async = true;
    g.src = ('https:' == location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    s.parentNode.insertBefore(g, s);
   })(document, 'script');
  </script>
  
</body>
</html>
